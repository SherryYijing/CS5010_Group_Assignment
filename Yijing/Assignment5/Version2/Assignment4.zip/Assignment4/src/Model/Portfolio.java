package Model;

import java.util.Map;

/**
 * An interface of portfolio. A portfolio of stocks is simply a collection of stocks.
 */
public interface Portfolio {
  /**
   * A getter for portfolio name.
   *
   * @return portfolio name.
   */
  String getPortfolioName();

  /**
   * A getter for getting stock's quantity.
   *
   * @param stockName the stock's name.
   * @return the quantity.
   */
  Integer getStockQuantity(String stockName);

  /**
   * A method set new stock into portfolio.
   *
   * @param stock the stock you want to set.
   */
  void setStocks(Stock stock);

  /**
   * Determine the total value of a portfolio on a certain date.
   *
   * @param certainDate input certain date.
   * @return the total value.
   */
  Double getTotalValue(String certainDate);
  StringBuilder getDataIntoStringBuilder(Map<String, Stock> savedStock);
  Boolean saveDataToFileHelper(StringBuilder sb, String name)
          throws IllegalArgumentException;

  /**
   * Save current portfolio to .csv file.
   *
   * @return true or false.
   * @throws IllegalArgumentException if open file fail, return error.
   */
  Boolean saveDataToFile() throws IllegalArgumentException;

  /**
   * Check if our portfolio is empty.
   *
   * @return true or false.
   */
  Boolean checkEmpty();

  /**
   * Determine the cost basis (i.e. the total amount of money invested in a portfolio) by a specific
   * date. This would include all the purchases made in that portfolio till that date.
   *
   * @param certainDate a specific date.
   * @return the cost basis till that date.
   */
  Double costBasis(String certainDate);
}
