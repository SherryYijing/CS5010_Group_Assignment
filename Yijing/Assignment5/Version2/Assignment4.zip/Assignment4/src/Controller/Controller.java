package Controller;

/**
 * the controller interface provides methods that dictate the actions of models and views.
 */
public interface Controller {

  /**
   * this is used to take inputs from users and delegates the work to model and view accordingly.
   */
  public void start();

}