package Model;

/**
 * A enum for different API type.
 */
public enum APIType {
  ALPHA_VANTAGE,
  OTHER
}
