package Controller;

import java.io.InputStream;
import java.util.Scanner;

import Model.Model;
import View.View;

/**
 * this class is used to implement functionality of controller interface
 * and here we design what work to delegate based on user input.
 */
public class ControllerImpl implements Controller {

  private Model model;
  private View view;
  private Scanner in;

  /**
   * constructor that takes in initialized model, inputstream and view.
   *
   * @param model model object that performs objectives.
   * @param in    inputstream object to take user input.
   * @param view  view object to use for display.
   */
  public ControllerImpl(Model model, InputStream in, View view) {
    this.model = model;
    this.in = new Scanner(in);
    this.view = view;
  }


  @Override
  public void start() {
    //tell view to show start page
    view.showStart();
    try {
      model.readDataFromALL();
      view.show("You are an existing user, loaded your portfolios successfully");
    } catch (Exception e) {
      view.show("You are a new user, no portfolios to load");
    }
    begin();
    view.showEnd();
  }

  /**
   * starting with default menu after display page.
   */
  private void begin() {
    boolean quit = false;
    while (!quit) {
      //accept user input
      view.showOptions();
      String option = in.next().toUpperCase();
      // main menu
      switch (option) {

        // create portfolio
        case "1":
          String portfolioName = "";
          //ask for name
          boolean flag = true;
          while (flag) {
            try {
              view.showEnterPortfolioName();
              portfolioName = in.next();
              model.createPortfolio(portfolioName, "");
              flag = false;
            } catch (Exception e) {
              view.show("Portfolio name already used!");
            }
          }
          view.show("Created portfolio name successfully");
          // create options
          nestedSwitchCreate(portfolioName);
          break;

        case "2":
          try {
            String ports = model.getPortfolioNames();
          } catch (Exception e) {
            view.show(e.getMessage());
            break;
          }
          nestedSwitchComposition();
          break;

        case "3":
          try {
            String ports = model.getPortfolioNames();
          } catch (Exception e) {
            view.show(e.getMessage());
            break;
          }

          String certainDate;
          view.show("Please enter date on which you would like to"
                  + " see total value (in YYYY-MM-DD format)");
          certainDate = in.next();
          nestedSwitchTotal(certainDate);
          break;

        case "E":
          quit = true;
          break;

        default:
          view.showOptionError();
          break;
      }
    }
  }

  /**
   * to implement nested switch cases required for creation of portfolio.
   *
   * @param portfolioName the name of the portfolio given by user.
   */
  private void nestedSwitchCreate(String portfolioName) {
    String createOption;
    String stockName;
    int stockQuantity;
    String stockBuyDate;
    boolean quit = false;

    while (!quit) {
      view.showCreateOptions();
      createOption = in.next().toUpperCase();
      switch (createOption) {
        case "1":
          String add = "Y";
          while (add.equals("Y")) {
            view.show("Please Enter the following [one word only]:");
            view.show("Stock ticker symbol [one word only]");
            stockName = in.next();
            boolean intflag = true;


            try {
              view.show("Stock quantity [integer value only]");
              stockQuantity = Integer.parseInt(in.next());
              view.show("Stock buyDate [in YYYY-MM-DD format]");
              stockBuyDate = in.next();
              try {
                model.buyShares(portfolioName, stockName, stockQuantity, stockBuyDate);
                view.show("Stock " + stockName + "( " + stockQuantity
                        + " shares ) added successfully to portfolio " + portfolioName);
              } catch (Exception e) {
                view.show(e.getMessage());
              }
            } catch (NumberFormatException e) {
              view.show("please enter integer type [without spaces] for stock quantity");
            }

            view.showAddMore();
            add = in.next().toUpperCase();

            while (!(add.equals("N") || add.equals("Y"))) {
              view.showOptionError();
              view.showAddMore();
              add = in.next().toUpperCase();
            }
          }
          quit = true;
          //helper to store all details
          try {
            model.saveDataToFile(portfolioName);
            view.show("Portfolio saved successfully in csv file [cannot modify now]");
          } catch (Exception e) {
            view.show(e.getMessage());
          }
          break;

        case "B":
          try {
            model.saveDataToFile(portfolioName);
            view.show("Portfolio saved successfully in csv file [cannot modify now]");
          } catch (Exception e) {
            view.show(e.getMessage());
          }
          quit = true;
          break;
        default:
          view.showOptionError();
          break;
      }
    }
  }

  /**
   * to implement nested switch cases required for viewing composition of portfolio.
   * user gets option to view individual portfolio or all at once.
   */
  private void nestedSwitchComposition() {
    boolean quit = false;
    String viewCompOption;

    while (!quit) {

      view.showViewCompositionOptions();
      viewCompOption = in.next().toUpperCase();

      switch (viewCompOption) {

        case "1":
          boolean flag = true;
          while (flag) {
            String portfolioName = "";
            String ports = model.getPortfolioNames();
            view.showPortfolioNames(ports);
            view.showEnterPortfolioName();
            portfolioName = in.next();
            // portfolio type check
            try {
              String s = model.viewCompositionIndividual(portfolioName);
              view.show(s);
              flag = false;
            } catch (Exception e) {
              view.show(e.getMessage());
            }
          }
          break;

        case "2":
          String all = model.toString();
          view.show(all);
          break;

        case "B":
          quit = true;
          break;

        default:
          view.showOptionError();
          break;
      }
    }
  }

  /**
   * to implement nested switch cases required for viewing total of portfolio.
   * user gets option to view individual portfolio or all at once.
   */
  private void nestedSwitchTotal(String certainDate) {
    boolean quit = false;
    String viewTotalOption;

    while (!quit) {

      view.showViewCompositionOptions();
      viewTotalOption = in.next().toUpperCase();
      boolean flag = true;

      switch (viewTotalOption) {

        case "1":
          while (flag) {
            String portfolioName = "";
            String ports = model.getPortfolioNames();
            view.showPortfolioNames(ports);
            view.showEnterPortfolioName();
            portfolioName = in.next();
            try {
              double d = model.getTotalValue(portfolioName, certainDate);
              view.show("Portfolio " + portfolioName + " value on " + certainDate + " is "
                      + d);
              flag = false;
            } catch (Exception e) {
              view.show(e.getMessage());
              flag = false;
            }
          }
          break;


        case "2":
          while (flag) {
            try {
              double d = model.getTotalValueCumulative(certainDate);
              view.show("Grand total value of all portfolios on " + certainDate + " is "
                      + d);
              flag = false;
            } catch (Exception e) {
              view.show(e.getMessage());
              flag = false;
            }
          }
          break;

        case "B":
          quit = true;
          break;

        default:
          view.showOptionError();
          break;
      }
    }
  }

}