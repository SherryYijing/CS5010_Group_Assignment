package Model;

/**
 * An interface of Model with portfolio creation and view related methods.
 */
public interface Model {
  /**
   * A method for creating a portfolio.
   *
   * @param portfolioName name for portfolio.
   * @param portfolioType flexible portfolio or not.
   * @return Portfolio.
   * @throws IllegalArgumentException if it cannot create, throw new error.
   */
  public Portfolio createPortfolio(String portfolioName, String portfolioType)
          throws IllegalArgumentException;

  /**
   * A method for buying stocks.
   *
   * @param portfolioName name for portfolio that you want to buy stock in it.
   * @param stockSymbol   ticker symbol for stock you want to buy.
   * @param quantity      how much stock you want to buy.
   * @param date          when you buy this stock.
   * @throws IllegalArgumentException if it cannot buy, throw new error.
   */
  void buyShares(String portfolioName, String stockSymbol, int quantity, String date)
          throws IllegalArgumentException;

  /**
   * Determine the total value of a portfolio on a certain date.
   *
   * @param portfolioName the name of portfolio that you want to get total value.
   * @param certainDate   the certain date at which we want current price.
   * @return the total value of specific portfolio in certain date.
   */
  double getTotalValue(String portfolioName, String certainDate);

  /**
   * Save specific portfolio into a file.
   *
   * @param portfolioName specific portfolio that you want to save.
   * @return true or false.
   * @throws IllegalArgumentException if file open fail, it will return error.
   */
  Boolean saveDataToFile(String portfolioName) throws IllegalArgumentException;

  /**
   * Read portfolio information from a file.
   *
   * @param fileName the name of file which you want to read.
   * @throws IllegalArgumentException if file open fail, it will return error.
   */
  void readDataFromFile(String fileName) throws IllegalArgumentException;

  /**
   * loads portfolio data of the user.
   *
   * @throws IllegalArgumentException if file open fail, it will return error.
   */
  void readDataFromALL() throws IllegalArgumentException;

  /**
   * view composition of a single portfolio.
   *
   * @param portfolio the portfolio name whose composition you want to view.
   * @return string containing composition of portfolio.
   */
  String viewCompositionIndividual(String portfolio);

  /**
   * lists all the portfolio names associated with user.
   *
   * @return string containing portfolio names.
   */
  String getPortfolioNames();

  /**
   * Determine the total value of a portfolio on a certain date.
   *
   * @param certainDate the certain date at which we want current price.
   * @return the total value of specific portfolio in certain date.
   */
  double getTotalValueCumulative(String certainDate);

  /**
   * checks if model is empty.
   */
  void emptyModelCheck();

  /**
   * gets size of model.
   *
   * @return the number of portfolios model has.
   */
  int getModelSize();

  /**
   * removes empty portfolio from list.
   */
  void removeEmptyPortfolio();

  /**
   * The total amount of money invested in a portfolio by a specific date. This would include all
   * the purchases made in that portfolio till that date.
   *
   * @param portfolioName the portfolio you want to check.
   * @param certainDate   specific date.
   * @param commissionFee brokers charge fee for each transaction.
   * @return cost basis.
   */
  Double costBasis(String portfolioName, String certainDate, int commissionFee);

  /**
   * Sell a specific number of shares of a specific stock on a specified date from given portfolio.
   *
   * @param portfolioName the portfolio you want to sell stock.
   * @param stockSymbol   the stock's name you want to sell.
   * @param quantity      how much stock you want to sell.
   * @param date          thw date you sell this stock.
   * @throws IllegalArgumentException if we cannot sell, throw error.
   */
  void sellShares(String portfolioName, String stockSymbol, int quantity, String date)
          throws IllegalArgumentException;
}
