package Model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * this class provides functionality for the portfolio creation and viewing methods
 * declared in the model interface.
 */
public class ModelImpl implements Model {

  //private final Map<String, Portfolio> model;
  private final Map<String, Portfolio> model;
  private final Map<String, String> types;

  /**
   * A constructor for ModelImpl assigns a new hashmap to the model to store portfolios.
   */
  public ModelImpl() {
    this.model = new HashMap<>();
    this.types = new HashMap<>();
  }

  @Override
  public Portfolio createPortfolio(String portfolioName, String portfolioType)
          throws IllegalArgumentException {
    // Check if portfolio already exist, we cannot create duplicate portfolio.
    if (this.model.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Portfolio already exists!");
    }
    Portfolio newPortfolio;
    if (portfolioType.equals("flexible")) {
      newPortfolio = new PortfolioExImpl(portfolioName);
      this.types.put(portfolioName, "flexible");
    } else {
      newPortfolio = new PortfolioImpl(portfolioName);
      this.types.put(portfolioName, "general");
    }
    this.model.put(portfolioName, newPortfolio);
    return newPortfolio;
  }

  @Override
  public void buyShares(String portfolioName, String stockSymbol, int quantity, String date)
          throws IllegalArgumentException {
    // Get portfolio from our portfolio map.
    Portfolio newPortfolio = this.model.get(portfolioName);
    String type = this.types.get(portfolioName);
    // If we don't have any portfolio called this name, then create a new one.
    if (newPortfolio == null) {
      newPortfolio = createPortfolio(portfolioName, "flexible");
    }
    try {
      // Add this stock to our portfolio map.
      Stock stock = new StockImpl(stockSymbol, quantity, date);
      newPortfolio.setStocks(stock);
    } catch (Exception exception) {
      throw new IllegalArgumentException(exception.getMessage());
    }
  }

  @Override
  public void sellShares(String portfolioName, String stockSymbol, int quantity, String date)
          throws IllegalArgumentException {
    // Get portfolio from our portfolio map.
    Portfolio newPortfolio = this.model.get(portfolioName);
    String type = this.types.get(portfolioName);
    // If we don't have any portfolio called this name, then create a new one.
    if (newPortfolio == null) {
      throw new IllegalArgumentException("No portfolio which name is " + portfolioName);
    }
    if (type.equals("flexible")) {
      Integer oldQuantity = newPortfolio.getStockQuantity(stockSymbol);
      if (oldQuantity < quantity) {
        throw new IllegalArgumentException("The quantity you want to sell is greater than the " +
                "quantity you own!");
      }
      dateCheck(date);
      int newQuantity = oldQuantity - quantity;
      if (newQuantity == 0) {
        ((PortfolioExImpl) newPortfolio).removeStock(stockSymbol, date);
      } else {
        ((PortfolioExImpl) newPortfolio).changeStockQuantity(stockSymbol,
                newQuantity, date);
      }
    } else {
      throw new IllegalArgumentException("Only flexible portfolio could sell shares!");
    }
  }

  @Override
  public double getTotalValue(String portfolioName, String certainDate)
          throws IllegalArgumentException {
    this.emptyModelCheck();

    if (!this.model.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Portfolio " + portfolioName + " doesn't exist!");
    }

    dateCheck(certainDate);

    // Use getTotalValue method from Portfolio class.
    return this.model.get(portfolioName).getTotalValue(certainDate);
  }


  @Override
  public double getTotalValueCumulative(String certainDate) throws IllegalArgumentException {
    this.emptyModelCheck();

    dateCheck(certainDate);

    double cumulative = 0.0;

    for (String portfolioName : this.model.keySet()) {
      cumulative += getTotalValue(portfolioName, certainDate);
    }
    return cumulative;
  }


  /**
   * checks whether the date given is valid with respect to data in api.
   *
   * @param certainDate the date to check.
   * @throws IllegalArgumentException if wrong, it will return error.
   */
  private void dateCheck(String certainDate) throws IllegalArgumentException {
    // Buy date cannot be empty.
    if (certainDate == null || certainDate.isEmpty()) {
      throw new IllegalArgumentException("The purchase date cannot be null!");
    }
    // Buy date cannot in the future.
    else if (LocalDate.parse(certainDate).isAfter(LocalDate.now())) {
      throw new IllegalArgumentException("The purchase date cannot on a future date!");
    }
    // Buy date cannot be weekend.
    else if (LocalDate.parse(certainDate).getDayOfWeek() == DayOfWeek.SUNDAY ||
            LocalDate.parse(certainDate).getDayOfWeek() == DayOfWeek.SATURDAY) {
      throw new IllegalArgumentException("No data on weekends");
    }
  }


  @Override
  public Boolean saveDataToFile(String portfolioName)
          throws IllegalArgumentException {
    this.removeEmptyPortfolio();
    Boolean flag = false;
    // Check if we have this portfolio.
    if (!this.model.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Empty portfolio " + portfolioName + " was discarded");
    }
    try {
      flag = this.model.get(portfolioName).saveDataToFile();
    } catch (Exception exception) {
      throw new IllegalArgumentException(exception.getMessage());
    }
    return flag;
  }

  @Override
  public void readDataFromFile(String fileName) throws IllegalArgumentException {
    String line = "";
    try {
      BufferedReader in = new BufferedReader(new FileReader(fileName));
      String s1 = fileName.substring(0, fileName.length() - 4);
      Portfolio newPortfolio = new PortfolioImpl(s1);
      line = in.readLine();
      // We have to ignore the first title line, so read next line here.
      line = in.readLine();
      while (line != null) {
        try {
          String[] st;
          st = line.split(",");
          String buyDate;
          int quantity;

          try {
            buyDate = (st[2]).toString();
          } catch (Exception e) {
            throw new IllegalArgumentException("Buy date should be string!");
          }
          try {
            quantity = Integer.parseInt(st[3]);
          } catch (Exception e) {
            throw new IllegalArgumentException("Quantity should be integer!");
          }
          newPortfolio.setStocks(new StockImpl(st[0], quantity, buyDate));
        } catch (IllegalArgumentException iae) {
          throw new IllegalArgumentException(iae.getMessage());
        }
        line = in.readLine();
      }
      this.model.put(s1, newPortfolio);
      this.types.put(s1, "general");
      in.close();
    } catch (Exception e) {
      throw new IllegalArgumentException("Cannot find " + fileName + "!");
    }
  }

  public void readDataForFlexiblePortfolio(String fileName)
  {
    String line = "";
    try {
      BufferedReader in = new BufferedReader(new FileReader(fileName));
      String s1 = fileName.substring(0, fileName.length() - 8);
      PortfolioExImpl newPortfolio = new PortfolioExImpl(s1);
      line = in.readLine();
      // We have to ignore the first title line, so read next line here.
      line = in.readLine();
      while (!Objects.equals(line, "stockHistory")) {
        try {
          String[] st;
          st = line.split(",");
          String buyDate;
          int quantity;

          try {
            buyDate = (st[2]).toString();
          } catch (Exception e) {
            throw new IllegalArgumentException("Buy date should be string!");
          }
          try {
            quantity = Integer.parseInt(st[3]);
          } catch (Exception e) {
            throw new IllegalArgumentException("Quantity should be integer!");
          }
          newPortfolio.setStocks(new StockImpl(st[0], quantity, buyDate));
        } catch (IllegalArgumentException iae) {
          throw new IllegalArgumentException(iae.getMessage());
        }
        line = in.readLine();
      }
      line = in.readLine();
      line = in.readLine();
      while(!Objects.equals(line, "soldStock"))
      {
        try {
          String[] st;
          st = line.split(",");
          String transDate;
          int quantity;

          try {
            transDate = (st[1]).toString();
          } catch (Exception e) {
            throw new IllegalArgumentException("Date should be string!");
          }
          try {
            quantity = Integer.parseInt(st[2]);
          } catch (Exception e) {
            throw new IllegalArgumentException("Quantity should be integer!");
          }
          newPortfolio.setStockHistory(st[0], transDate, quantity);
        } catch (IllegalArgumentException iae) {
          throw new IllegalArgumentException(iae.getMessage());
        }
        line = in.readLine();
      }
      line = in.readLine();
      line = in.readLine();
      while(line != null)
      {
        try {
          String[] st;
          st = line.split(",");
          String buyDate;
          int quantity;

          try {
            buyDate = (st[2]).toString();
          } catch (Exception e) {
            throw new IllegalArgumentException("Buy date should be string!");
          }
          try {
            quantity = Integer.parseInt(st[3]);
          } catch (Exception e) {
            throw new IllegalArgumentException("Quantity should be integer!");
          }
          newPortfolio.setSoldStock(st[0], new StockImpl(st[0], quantity, buyDate));
        } catch (IllegalArgumentException iae) {
          throw new IllegalArgumentException(iae.getMessage());
        }
        line = in.readLine();
      }

      this.model.put(s1, newPortfolio);
      this.types.put(s1, "flexible");
      in.close();
    } catch (Exception e) {
      throw new IllegalArgumentException("Cannot find " + fileName + "!");
    }
  }

  @Override
  public void readDataFromALL() throws IllegalArgumentException {

    final File folder = new File(System.getProperty("user.dir"));

    List<String> filenames = new LinkedList<String>();
    File[] list = folder.listFiles();

    if (list == null) {
      throw new IllegalArgumentException("No file under this path!");
    }

    for (final File file : list) {
      if (file.getName().contains(".csv")) {
        if (file.getName().contains("flex"))
        {
          readDataForFlexiblePortfolio(file.getName());
        }
        else
        {
          readDataFromFile(file.getName());
        }
        filenames.add(file.getName());
      }
    }
    if (filenames.isEmpty()) {
      throw new IllegalArgumentException("No .csv file under this path!");
    }
  }

  @Override
  public String viewCompositionIndividual(String portfolioName) {
    if (!this.model.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Portfolio not present");
    }
    StringBuilder output = new StringBuilder();
    Portfolio newPortfolio = this.model.get(portfolioName);
    output.append(newPortfolio.toString());
    output.append("\n");
    return output.toString();
  }


  @Override
  public String toString() {
    StringBuilder output = new StringBuilder();

    for (Portfolio portfolio : this.model.values()) {
      output.append(portfolio.toString());
      output.append("\n");
    }
    return output.toString();
  }

  @Override
  public String getPortfolioNames() {
    this.emptyModelCheck();
    StringBuilder output = new StringBuilder();
    for (String portfolioName : this.model.keySet()) {
      output.append(portfolioName + "\t");
    }
    return output.toString();
  }

  @Override
  public void emptyModelCheck() throws IllegalArgumentException {
    if (this.model.keySet().isEmpty()) {
      throw new IllegalStateException("There are no portfolios, create portfolio first!");
    }
  }

  @Override
  public int getModelSize() {
    return this.model.size();
  }

  @Override
  public void removeEmptyPortfolio() {
    this.model.values().removeIf(portfolio -> portfolio.checkEmpty());
    for(String name: this.types.keySet())
    {
      if(!this.model.containsKey(name))
      {
        this.types.remove(name);
      }
    }
  }

  @Override
  public Double costBasis(String portfolioName, String certainDate, int commissionFee) {
    return this.model.get(portfolioName).costBasis(certainDate) + commissionFee;
  }

  @Override
  public Map<String, Double> performanceOverTime(String portfolioName, String durationFrom,
                                                 String durationTo) throws IllegalArgumentException
  {
    if(!this.model.containsKey(portfolioName))
    {
      throw new IllegalArgumentException("We don't have this portfolio!");
    }

    Map<String, Double> result = new HashMap<>();
    Portfolio portfolio = this.model.get(portfolioName);
    LocalDate start;
    LocalDate end;
    if(durationFrom.isEmpty())
    {
      throw new IllegalArgumentException("Start date cannot be null!");
    }
    if(durationTo.isEmpty())
    {
      durationTo = LocalDate.now().toString();
    }
    try {
      start = LocalDate.parse(durationFrom);
      end = LocalDate.parse(durationTo);
    }
    catch (Exception exception)
    {
      throw new IllegalArgumentException("Input duration date must be yyyy-mm-dd format!");
    }

    if(start.isAfter(LocalDate.now()))
    {
      throw new IllegalArgumentException("Start date must be before today!");
    }
    if(start.isAfter(end))
    {
      throw new IllegalArgumentException("Start date must be after end date!");
    }
    while(start.getMonth() != end.getMonth())
    {
      LocalDate lastDateOfStartMonth = start.with(TemporalAdjusters.lastDayOfMonth());
      result.put(start.getMonth().toString() + " " + start.getYear(), portfolio
              .getTotalValue(lastDateOfStartMonth.toString()));
      start = start.plusMonths(1);
    }
    if(!start.equals(end))
    {
      result.put(end.getMonth().toString() + " " + end.getYear(),
              portfolio.getTotalValue(end.toString()));
    }
    return result;
  }
}
