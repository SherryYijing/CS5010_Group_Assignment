package View;

/**
 * this interface declares methods used to show user any output or display.
 */
public interface View {

  /**
   * displays starting screen.
   */
  public void showStart();

  /**
   * displays main menu.
   */
  public void showOptions();

  /**
   * displays invalid option message.
   */
  public void showOptionError();

  /**
   * displays create option menu.
   */
  public void showCreateOptions();

  /**
   * displays view composition menu.
   */
  public void showViewCompositionOptions();

  /**
   * displays view total menu.
   */
  public void showViewTotalOptions();

  /**
   * displays information regarding what is needed to add stock.
   */
  public void showAddStockDetails();

  /**
   * asks user whether they want to add more stock.
   */
  public void showAddMore();

  /**
   * asks user to enter portfolio name.
   */
  public void showEnterPortfolioName();

  /**
   * shows user all portfolio names.
   *
   * @param s the string with all portfolio names.
   */
  public void showPortfolioNames(String s);

  /**
   * shows user all upload options.
   */
  public void showUploadOptions();

  /**
   * displays end message.
   */
  public void showEnd();

  /**
   * displays any string passed to it.
   *
   * @param s the strng message to be shown.
   */
  public void show(String s);

  /**
   * displays double value as string.
   *
   * @param d the double value to be displayed.
   */
  public void showValue(double d);


}