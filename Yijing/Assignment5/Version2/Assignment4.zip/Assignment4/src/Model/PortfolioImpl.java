package Model;

/**
 * An implement for Portfolio interface.
 */
public class PortfolioImpl extends AbstractPortfolio {
  protected PortfolioImpl(String portfolioName) throws IllegalArgumentException {
    super(portfolioName);
  }

  @Override
  public void setStocks(Stock stock) throws IllegalArgumentException {
    // Check the stock we want to set if it is already in our portfolio.
    if (this.stocks.containsKey(stock.getStockTickerSymbol())) {
      throw new IllegalArgumentException("This stock's already in portfolio!");
    }
    super.setStocks(stock);
  }
}
