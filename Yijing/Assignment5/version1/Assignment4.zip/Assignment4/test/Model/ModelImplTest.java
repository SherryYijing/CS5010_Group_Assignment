package Model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * A test for ModelImpl.
 */
public class ModelImplTest {
  Model model;

  @Before
  public void setUp() {
    this.model = new ModelImpl();
  }

  @Test
  public void getModelSizeTest() {
    assertEquals(0, this.model.getModelSize());
  }

  /**
   * createPortfolio() Test: create a new portfolio with string input as portfolio name. If this
   * method work, it should return new portfolio object.
   */
  @Test
  public void createPortfolioTest() {
    Portfolio newPortfolio = this.model.createPortfolio("Yijing's Portfolio",
            "general");
    assertEquals("Yijing's Portfolio", newPortfolio.getPortfolioName());
  }

  /**
   * createPortfolio() Test: create two new portfolios with string input as portfolio name, but we
   * use same name twice. If this method work, it should return an IllegalArgumentException.
   */
  @Test
  public void createPortfolioButExistTest() {
    this.model.createPortfolio("Yijing's Portfolio", "general");
    try {
      this.model.createPortfolio("Yijing's Portfolio", "general");
    } catch (IllegalArgumentException iae) {
      assertEquals("Portfolio already exists!", iae.getMessage());
    }
  }

  /**
   * toString() Test: this method will show portfolios' name and all stock under each portfolio. If
   * no stock under portfolio, then just only show the portfolio's name.
   */
  @Test
  public void toStringTest() {
    this.model.createPortfolio("Yijing's Portfolio", "general");
    assertEquals("Portfolio name: Yijing's Portfolio\n\n", this.model.toString());
  }

  /**
   * buyShares() Test: this method will apply for buy shares. It takes the portfolio's name that you
   * want to buy stock, ticker symbol, quantity, and buy date.
   */
  @Test
  public void buySharesTest() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-27");
    assertEquals("Portfolio name: yijing\nTicker name: GOOG, Buy price per stock: 92.6, "
            + "Stock quantity: 100, Purchase date: 2022-10-27\n\n", this.model.toString());
  }

  /**
   * buyShares() Test: one more test but this time we input an invalid stock symbol. If it works,
   * it should throw an IllegalArgumentException.
   */
  @Test
  public void buySharesFailTest() {
    try {
      this.model.buyShares("shamekh", "yijing", 100,
              "2022-10-27");
    } catch (IllegalArgumentException iae) {
      assertEquals("No data found for yijing!", iae.getMessage());
    }
  }

  /**
   * getTotalValueCumulative Test(): this method will show how much stock value you have for
   * specific portfolio in certain date.
   */
  @Test
  public void getTotalValueCumulativeTest1() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.buyShares("shamekh", "GOOG", 100, "2022-10-27");
    assertEquals(9930, this.model.getTotalValueCumulative(
            "2022-10-03"), 0.01);
  }

  /**
   * getTotalValueCumulative Test(): if we have only empty portfolio, it will throw error message.
   */
  @Test
  public void getTotalValueCumulativeTest2() {
    try {
      this.model.createPortfolio("yijing", "general");
    } catch (IllegalStateException ise) {
      assertEquals("There are no portfolios", ise.getMessage());
    }
  }

  /**
   * getTotalValueCumulative Test(): if we input invalid date, it will throw error message.
   */
  @Test
  public void getTotalValueCumulativeTest3() {
    try {
      this.model.buyShares("yijing", "GOOG", 100, "");
    } catch (IllegalArgumentException iae) {
      assertEquals("The purchase date cannot be null!", iae.getMessage());
    }
  }

  /**
   * getTotalValueCumulative Test(): if we input invalid date, it will throw error message.
   */
  @Test
  public void getTotalValueCumulativeTest4() {
    try {
      this.model.buyShares("yijing", "GOOG", 100, "2050-11-02");
    } catch (IllegalArgumentException iae) {
      assertEquals("The purchase date cannot on a future date!", iae.getMessage());
    }
  }

  /**
   * getTotalValueCumulative Test(): if we input invalid date, it will throw error message.
   */
  @Test
  public void getTotalValueCumulativeTest5() {
    try {
      this.model.buyShares("yijing", "GOOG", 100, "2022-10-30");
    } catch (IllegalArgumentException iae) {
      assertEquals("Only weekday could buy stocks!", iae.getMessage());
    }
  }

  /**
   * saveDateToFile() Test: save current portfolio into a file. If it works, it will return true.
   */
  @Test
  public void saveDateToFileTest() {
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.buyShares("shamekh", "GOOG", 100, "2022-10-27");
    assertEquals(true, this.model.saveDataToFile("yijing"));
  }

  /**
   * saveDateToFile() Test: save current portfolio into a file which doesn't exist. If it works, it
   * will return IllegalArgumentException.
   */
  @Test
  public void saveDateFromFileFailTest1() {
    try {
      this.model.saveDataToFile("aEmptyPortfolio");
    } catch (IllegalArgumentException iae) {
      assertEquals("Empty portfolio aEmptyPortfolio was discarded", iae.getMessage());
    }
  }

  /**
   * saveDateToFile() Test: save current portfolio into a file which is an empty one. Empty
   * portfolio will be removed before we save. If it works, it will return IllegalArgumentException.
   */
  @Test
  public void saveDateFromFileFailTest2() {
    this.model.createPortfolio("yijing", "general");
    try {
      this.model.saveDataToFile("yijing");
    } catch (IllegalArgumentException iae) {
      assertEquals("Empty portfolio yijing was discarded", iae.getMessage());
    }
  }

  /**
   * readDateToFile() Test: read portfolio information from a file which doesn't exist. If it works,
   * it will return IllegalArgumentException.
   */
  @Test
  public void readDateFromFileFailTest() {
    try {
      this.model.readDataFromFile("Yijing");
    } catch (IllegalArgumentException iae) {
      assertEquals("Cannot find Yijing!", iae.getMessage());
    }
  }

  /**
   * removeEmptyPortfolio() Test: remove an empty portfolio from our model. If it works, the model
   * size will change to 0 after removing.
   */
  @Test
  public void removeEmptyPortfolioTest() {
    this.model.createPortfolio("Yijing's Portfolio", "");
    assertEquals(1, this.model.getModelSize());
    this.model.removeEmptyPortfolio();
    assertEquals(0, this.model.getModelSize());
  }

  /**
   * viewCompositionIndividual() Test: see if we could get correct composition.
   */
  @Test
  public void viewCompositionIndividualTest() {
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    assertEquals("Portfolio name: yijing\nTicker name: IBM, Buy price per stock: 134.77,"
                    + " Stock quantity: 100, Purchase date: 2022-10-27\n\n",
            this.model.viewCompositionIndividual("yijing"));
  }

  /**
   * viewCompositionIndividual() Test: if input portfolio is empty, then it will not be presented.
   */
  @Test
  public void viewCompositionIndividualFailTest() {
    try {
      this.model.viewCompositionIndividual("empty");
    } catch (IllegalArgumentException iae) {
      assertEquals("Portfolio not present", iae.getMessage());
    }

  }

  /**
   * getPortfolioNames() Test: get all portfolio names from model. If it works, it will return
   * correct string.
   */
  @Test
  public void getPortfolioNamesTest() {
    this.model.createPortfolio("Yijing's Portfolio", "");
    this.model.createPortfolio("Shamekh's Portfolio", "");
    assertEquals("Shamekh's Portfolio" + "\t" + "Yijing's Portfolio" + "\t",
            this.model.getPortfolioNames());
  }

  /**
   * emptyModelCheck() Test: when we have a empty model, it will throw error message.
   */
  @Test
  public void emptyModelCheckTest() {
    try {
      this.model.emptyModelCheck();
    } catch (IllegalStateException ise) {
      assertEquals("There are no portfolios, create portfolio first!", ise.getMessage());
    }
  }

  /**
   * sellShares() Test: sell a specific number of shares of a specific stock on a specified date
   * from a given portfolio. If it works,the string will show correct information.
   */
  @Test
  public void sellSharesTest1() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.sellShares("yijing", "GOOG", 50, "2022-11-01");
    assertEquals("Portfolio name: yijing\nTicker name: GOOG, Buy price per stock: 99.3, "
                    + "Stock quantity: 50, Purchase date: 2022-10-03\nTicker name: IBM, Buy price "
                    + "per stock: 134.77, Stock quantity: 100, Purchase date: 2022-10-27\n\n",
            this.model.toString());
  }

  /**
   * sellShares() Test: one more test.
   */
  @Test
  public void sellSharesTest2() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.sellShares("yijing", "GOOG", 70, "2022-11-01");
    assertEquals("Portfolio name: yijing\nTicker name: GOOG, Buy price per stock: 99.3, "
                    + "Stock quantity: 30, Purchase date: 2022-10-03\nTicker name: IBM, Buy price "
                    + "per stock: 134.77, Stock quantity: 100, Purchase date: 2022-10-27\n\n",
            this.model.toString());
  }

  /**
   * sellShares() Test: one more test.
   */
  @Test
  public void sellSharesTest3() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.sellShares("yijing", "GOOG", 100, "2022-11-01");
    assertEquals("Portfolio name: yijing\nTicker name: IBM, Buy price per stock: 134.77, "
            + "Stock quantity: 100, Purchase date: 2022-10-27\n\n", this.model.toString());
  }

  /**
   * sellShares() Test: if the quantity you want to sell is greater than how much you own, then it
   * will return IllegalArgumentException.
   */
  @Test
  public void sellSharesFailTest1() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    try {
      this.model.sellShares("yijing", "GOOG", 200, "2022-11-01");
    } catch (IllegalArgumentException iae) {
      assertEquals("The quantity you want to sell is greater than the quantity you own!",
              iae.getMessage());
    }
  }

  /**
   * sellShares() Test: you cannot sell stock in a future date.
   */
  @Test
  public void sellSharesFailTest2() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    try {
      this.model.sellShares("yijing", "GOOG", 20, "2025-11-01");
    } catch (IllegalArgumentException iae) {
      assertEquals("The purchase date cannot on a future date!", iae.getMessage());
    }
  }

  /**
   * costBasis() Test: the total amount of money invested in a portfolio by a specific date. This
   * would include all the purchases made in that portfolio till that date and plus with commission
   * fees.
   */
  @Test
  public void costBasisTest1() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.buyShares("yijing", "AAPL", 150, "2022-11-03");
    assertEquals(23507, this.model.costBasis("yijing", "2022-11-01",
            100), 0.01);
  }

  /**
   * costBasis() Test: one more test.
   */
  @Test
  public void costBasisTest2() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.buyShares("yijing", "AAPL", 150, "2022-11-03");
    this.model.sellShares("yijing", "GOOG", 50, "2022-11-09");
    assertEquals(23507, this.model.costBasis("yijing", "2022-11-01",
            100), 0.01);
  }

  /**
   * costBasis() Test: one more test.
   */
  @Test
  public void costBasisTest3() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.buyShares("yijing", "AAPL", 150, "2022-11-03");
    this.model.sellShares("yijing", "GOOG", 50, "2022-11-01");
    assertEquals(18542, this.model.costBasis("yijing", "2022-11-01",
            100), 0.01);
  }

  /**
   * costBasis() Test: one more test.
   */
  @Test
  public void costBasisTest4() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.buyShares("yijing", "AAPL", 150, "2022-11-03");
    this.model.sellShares("yijing", "GOOG", 100, "2022-11-01");
    assertEquals(13577, this.model.costBasis("yijing", "2022-11-01",
            100), 0.01);
  }

  /**
   * costBasis() Test: one more test.
   */
  @Test
  public void costBasisTest5() {
    this.model.buyShares("yijing", "GOOG", 100, "2022-10-03");
    this.model.buyShares("yijing", "IBM", 100, "2022-10-27");
    this.model.buyShares("yijing", "AAPL", 150, "2022-11-03");
    this.model.sellShares("yijing", "GOOG", 100, "2022-11-09");
    assertEquals(23507, this.model.costBasis("yijing", "2022-11-01",
            100), 0.01);
  }
}