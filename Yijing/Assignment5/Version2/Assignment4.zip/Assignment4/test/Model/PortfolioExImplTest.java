package Model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PortfolioExImplTest extends AbstractPortfolioTest {

  PortfolioEx portfolioEx = getPortfolioInstance();

  /**
   * Before we start test, set up first.
   */
  @Override
  protected PortfolioExImpl getPortfolioInstance() {
    return new PortfolioExImpl("test1");
  }

  /**
   * changeStockQuantity() Test: change a specific number of shares of a specific stock on a
   * specified date from a given portfolio. If it works, it should return correctly.
   */
  @Test
  public void changeStockQuantityTest() {
    Stock stock = new StockImpl("GOOG", 100, "2022-10-03");
    this.portfolioEx.setStocks(stock);
    this.portfolioEx.changeStockQuantity("GOOG", 150, "2022-10-03");
    assertEquals("Portfolio name: test1\nTicker name: GOOG, Buy price per stock: 99.3, "
                    + "Stock quantity: 150, Purchase date: 2022-10-03\n",
            this.portfolioEx.toString());
  }

  /**
   * changeStockQuantity() Test: we cannot change quantity of non-exist stock. If it works, it
   * should throw IllegalArgumentException.
   */
  @Test
  public void changeStockQuantityFailTest() {
    try {
      this.portfolioEx.changeStockQuantity("GOOG", 150, "2022-10-03");
    } catch (IllegalArgumentException iae) {
      assertEquals("No stock name is GOOG in current portfolio test1", iae.getMessage());
    }
  }

  /**
   * getTotalValue() Test: determine the value of a portfolio on a specific date. If it works,
   * it should return correct amount of money.
   */
  @Test
  public void getTotalValueTest1() {
    Stock stock1 = new StockImpl("GOOG", 100, "2022-10-03");
    Stock stock2 = new StockImpl("IBM", 100, "2022-10-03");
    this.portfolioEx.setStocks(stock1);
    this.portfolioEx.setStocks(stock2);
    this.portfolioEx.changeStockQuantity("IBM", 50, "2022-11-09");
    assertEquals(22870, this.portfolioEx.getTotalValue("2022-11-01"),
            0.01);
  }

  /**
   * getTotalValue() Test: one more test.
   */
  @Test
  public void getTotalValueTest2() {
    Stock stock1 = new StockImpl("GOOG", 100, "2022-10-03");
    Stock stock2 = new StockImpl("IBM", 100, "2022-10-03");
    Stock stock3 = new StockImpl("AAPL", 150, "2022-11-03");
    this.portfolioEx.setStocks(stock1);
    this.portfolioEx.setStocks(stock2);
    this.portfolioEx.setStocks(stock3);
    this.portfolioEx.changeStockQuantity("IBM", 50, "2022-11-09");
    assertEquals(22870, this.portfolioEx.getTotalValue("2022-11-01"),
            0.01);
  }

  /**
   * getTotalValue() Test: one more test. The value for a portfolio before the date of its
   * first purchase would be 0, since each stock in the portfolio now was purchased at a specific
   * point in time.
   */
  @Test
  public void getTotalValueTest3() {
    Stock stock1 = new StockImpl("GOOG", 100, "2022-10-03");
    this.portfolioEx.setStocks(stock1);
    assertEquals(0, this.portfolioEx.getTotalValue("2022-10-01"), 0.01);
  }
}