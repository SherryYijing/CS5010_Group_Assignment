import Controller.Controller;
import Controller.ControllerImpl;
import Model.Model;
import Model.ModelImpl;
import View.View;
import View.ViewImpl;

/**
 * this main class is where all objects of model, controller and view classes are initialized
 * and the application or program starts by callign the controller.
 */
public class StockMarketMain {

  /**
   * this main method is used to start the application by calling start method or controller.
   *
   * @param args a stream of inputs from user in the command line.
   */
  public static void main(String[] args) {
    Model model = new ModelImpl();
    View view = new ViewImpl(System.out);
    Controller controller = new ControllerImpl(model, System.in, view);
    controller.start();
  }
}