package Model;

public interface PortfolioEx extends Portfolio {
  /**
   * This method will update a specific number of shares of a specific stock on a specified date
   * from a given portfolio
   *
   * @param stockName   the stock you want to make changed.
   * @param newQuantity new quantity.
   * @param certainDate specified date.
   */
  void changeStockQuantity(String stockName, Integer newQuantity, String certainDate);
  void setSoldStock(String name, Stock stock);

  /**
   * Set old quantity and transaction date into HashMap.
   *
   * @param name     the stock's name.
   * @param date     the date to make this transaction.
   * @param quantity old quantity value before any change.
   */
  public void setStockHistory(String name, String date, Integer quantity);

  /**
   * Remove stock from HashMap.
   *
   * @param stockName the stock we want to remove.
   * @param date      in this date we remove it.
   */
  void removeStock(String stockName, String date);
}
