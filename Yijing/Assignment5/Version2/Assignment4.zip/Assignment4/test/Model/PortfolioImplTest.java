package Model;

/**
 * A test for PortfolioImpl.
 */
public class PortfolioImplTest extends AbstractPortfolioTest {
  Portfolio portfolio = getPortfolioInstance();

  /**
   * Before we start test, set up first.
   */
  @Override
  protected PortfolioImpl getPortfolioInstance() {
    return new PortfolioImpl("test1");
  }
}