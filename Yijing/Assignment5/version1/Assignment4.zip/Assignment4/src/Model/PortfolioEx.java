package Model;

public interface PortfolioEx extends Portfolio {
  /**
   * This method will update a specific number of shares of a specific stock on a specified date
   * from a given portfolio
   *
   * @param stockName   the stock you want to make changed.
   * @param newQuantity new quantity.
   * @param certainDate specified date.
   */
  void changeStockQuantity(String stockName, Integer newQuantity, String certainDate);

  /**
   * Set old quantity and transaction date into HashMap.
   *
   * @param name     the stock's name.
   * @param date     the date to make this transaction.
   * @param quantity old quantity value before any change.
   */
  public void setStockHistory(String name, String date, Integer quantity);

  /**
   * A getter for getting stock's quantity.
   *
   * @param stockName the stock's name.
   * @return the quantity.
   */
  Integer getStockQuantity(String stockName);

  /**
   * Remove stock from HashMap.
   *
   * @param stockName the stock we want to remove.
   * @param date      in this date we remove it.
   */
  void removeStock(String stockName, String date);
}
